// app-cursos/src/screens/AddCursoScreen.js
import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet, Alert } from 'react-native';
import axios from 'axios';

const API_URL = 'http://192.168.1.211:3000/cursos';

export default function AddCursoScreen({ navigation }) {
  const [nome, setNome] = useState('');
  const [area, setArea] = useState('');

  const handleAddCurso = async () => {
    if (!nome || !area) {
      Alert.alert('Atenção', 'Por favor, preencha todos os campos.');
      return;
    }
    try {
      await axios.post(API_URL, { nome, area });
      navigation.goBack();
    } catch (error) {
      Alert.alert('Erro', 'Erro ao adicionar curso.');
    }
  };

  return (
    <View style={styles.container}>
      <TextInput placeholder="Nome do Curso" value={nome} onChangeText={setNome} style={styles.input} />
      <TextInput placeholder="Área do Curso" value={area} onChangeText={setArea} style={styles.input} />
      <Button title="Salvar Curso" onPress={handleAddCurso} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f5f5f5' },
  input: {
    backgroundColor: '#fff', height: 50, borderColor: '#ddd', borderWidth: 1, borderRadius: 8,
    marginBottom: 20, paddingHorizontal: 15, fontSize: 16,
  },
});